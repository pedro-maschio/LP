import System.IO
import Text.Printf 
import Prelude

calculaR1 :: Double -> Double -> Double -> Double
calculaR1 b d a = ((-b) + sqrt d) / (2 * a)

calculaR2 :: Double -> Double -> Double -> Double
calculaR2 b d a = ((-b) - sqrt d) / (2 * a)

bhaskara :: Double -> Double -> Double -> String
bhaskara a b c 
    | d < 0 || a == 0 = "Impossivel calcular\n"
    | otherwise = printf "R1 = %.5f\nR2 = %.5f\n" (calculaR1 b d a) (calculaR2 b d a)
    where d = b^2 - (4.0 * a * c)

main :: IO ()
main = do
        input <- getLine
        let scan = map read $ words input :: [Double]
        printf ("%s") (bhaskara (scan !! 0) (scan !! 1) (scan !! 2))