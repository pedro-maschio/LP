import Data.Bifunctor (Bifunctor(second))
type Person = String 
type Book = String 
type Database = [(Person, Book)]

db = [("Alice","Postman Pat"), ("Anna","All Alone"), ("Alice","Spot"), ("Rory","Postman Pat")]

books :: Database -> Person -> [Book]
books [] _ = []
books ((x,y):as) p 
    | x == p = y : books as p
    | otherwise = books as p 

books2 :: Database -> Person -> [Book]
books2 db p = [book | (person, book) <- db, person == p]

makeLoan :: Database -> Person -> Book -> Database
makeLoan db p b = (p,b) : db

makeLoan2 :: Database -> Person -> Book -> Database
makeLoan2 [] p b = [(p,b)]
makeLoan2 ((p,l):dbs) pessoa livro
    | (p,l) == (pessoa, livro) = (p, l) : dbs
    | otherwise = (p,l) : makeLoan2 dbs pessoa livro

borrowers :: Database -> Book -> [Person]
borrowers [] _ = []
borrowers ((p,l):dbs) livro 
    | l == livro = p : borrowers dbs livro
    | otherwise = borrowers dbs livro

borrowers2 :: Database -> Book -> [Person]
borrowers2 db l = [nome | (nome, livro) <- db, livro == l]

isBorrowed :: Database -> Book -> Bool 
isBorrowed [] _ = False 
isBorrowed ((_,l):dbs) livro
    | l == livro = True 
    | otherwise = isBorrowed dbs livro

isBorrowed2 :: Database -> Book -> Bool
isBorrowed2 db b = borrowers db b /= [] 

numBorrowed :: Database -> Book -> Int 
numBorrowed [] _ = 0
numBorrowed ((p,l):dbs) livro 
    | l == livro = 1 + numBorrowed dbs livro 
    | otherwise = numBorrowed dbs livro

numBorrowed2 :: Database -> Book -> Int 
numBorrowed2 db p = length (books db p)

returnLoan :: Database -> Person -> Book -> Database
returnLoan [] _ _ = [] 
returnLoan ((p,l):dbs) pessoa livro
    | (p,l) == (pessoa, livro) = dbs
    | otherwise = (p,l) : returnLoan dbs pessoa livro

returnLoan2 :: Database -> Person -> Book -> Database
returnLoan2 db p l = [(nome, livro) | (nome, livro) <- db, (nome, livro) /= (p, l)]


