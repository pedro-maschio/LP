somaMatriz :: [[Int]] -> [[Int]] -> [[Int]]
somaMatriz [] [] = []
somaMatriz (x:xas) (y:yas) = zipWith (+) x y : somaMatriz xas yas

somaLista :: Num a => [a] -> [a] -> [a]
somaLista [] [] = []
somaLista (x:xs) (y:ys) = x + y : somaLista xs ys

somaMatriz2 :: Num a => [[a]] -> [[a]] -> [[a]]
somaMatriz2 [] [] = []
somaMatriz2 (x:xs) (y:ys) = somaLista x y : somaMatriz2 xs ys 

somaLista2 lista1 lista2 = zipWith (+) lista1 lista2

somaMatriz3 :: Num a => [[a]] -> [[a]] -> [[a]]
somaMatriz3 = zipWith somaLista2

{-

1 2 3  
4 5 6
7 8 9

10 11 12
13 14 15
16 17 18
------
11 13 15
17 19 21
23 25 27

-}