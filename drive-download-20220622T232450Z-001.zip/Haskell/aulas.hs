import Data.Sequence.Internal.Sorting (QList(Nil))
fat :: Int -> Int
fat n
    | n < 0 = -1
    | n == 0 = 1
    | otherwise = n * fat (n-1)

square :: Int -> Int
square x = x * x

--allEqual :: Int -> Int -> Int -> Bool
allEqual n m p = (n == m) && (m == p)

maxi :: Int -> Int -> Int
maxi n m 
    | n >= m = n
    | otherwise = m

mini :: Int -> Int -> Int
mini n m 
    | n <= m = n
    | True = m

addD :: Int -> Int -> Int
addD a b = 2 * (a+b)

-- Exercícios

all4equal :: Int -> Int -> Int -> Int -> Bool
all4equal a b c d = allEqual a b c && c == d

howManyEqual :: Int -> Int -> Int -> Int
howManyEqual a b c
    | allEqual a b c = 3
    | (a == b) || (b == c) || (a == c) = 2
    | otherwise = 0

howManyEqual2 :: Int -> Int -> Int -> Int
howManyEqual2 a b c = if (allEqual a b c)
                        then 3
                        else if ((a == b) || (b == c) || (a == c))
                            then 2
                            else 0

-- Casamento de padrões

sales :: Int -> Int
sales 0 = 1
sales 1 = 0
sales 2 = 10
sales 3 = 5
sales 4 = 10

f :: Int -> Int -> Int
f s 0 = if ((sales 0) == s)
            then 1
            else 0
f s n = if ((sales n) == s)
            then 1 + f s (n - 1)
            else f s (n - 1)

f2 :: Int -> Int -> Int
f2 s n
    | n == 0 && (sales 0 == s) = 1
    | n == 0 = 0
    | n > 0 && (sales n == s) = 1 + f2 s (n - 1)
    | n > 0 = f2 s (n - 1)

makeSpaces :: Int -> String
makeSpaces 0 = ""
makeSpaces n
        | n > 0 = " " ++ makeSpaces (n-1)

pushRight :: Int -> String -> String
pushRight n s = (makeSpaces n) ++ s

addPair :: (Int, Int) -> Int
addPair (x,y) = x+y

shift :: ((Int, Int), Int) -> (Int,(Int,Int))
shift ((x,y),z) = (x,(y,z))

sumSquare :: Int -> Int -> Int
sumSquare x y =  sqX + sqY
    where sqX = x * x 
          sqY = y * y

sumSquare2 :: Int -> Int -> Int
sumSquare2 x y =  sq x + sq y
    where sq z = z * z

sumList :: [Int] -> Int 
sumList [] = 0 -- caso base
sumList (a:as) = a + sumList as -- a = cabeça da lista, as = restante da lista, a \= as

double :: [Int] -> [Int]
double [] = []
double (a:as) = (2 * a) : double as

sumPairs :: [(Int, Int)] -> [Int]
sumPairs [] = []
sumPairs ((x,y):as) = (x + y) : sumPairs as

--member :: [Int] -> Int -> Bool
member [] _ = False
member (a:as) n
    | n == a = True
    | otherwise = member as n

digits :: String -> String
digits [] = ""
digits (a:as)
    | a == '0' || a == '2' || a == '3' || a == '4' || a == '5' || a == '6' || a == '7' || a == '8' || a == '9' = a : digits as
    | otherwise = digits as

reverseString :: String -> String
reverseString [] = []
reverseString (a:as) = reverseString as ++ [a]

-- Compreensão de listas

isEven :: Int -> Bool 
isEven n = even n

doubleList :: [Int] -> [Int]
doubleList xs = [2*a|a <- xs]

doubleIfEven :: [Int] -> [Int]
doubleIfEven xs = [2*a|a <- xs, isEven a]

--quickSort :: [Int] -> [Int]
quickSort [] = []
quickSort (x:xs) = quickSort [e | e <- xs, e <= x] ++ [x] ++ quickSort [e | e <- xs, e > x]

maxFun :: (Int -> Int) -> Int -> Int 
maxFun f 0 = f 0
maxFun f n = maxi (maxFun f(n-1)) (f n)

maxSales :: Int -> Int 
maxSales n | n == 0 = sales 0
           | n > 0 = maxi(maxSales (n-1)) (sales n)
           
isCrescent :: (Int -> Int) -> Int -> Bool 
isCrescent f 0 = True 
isCrescent f n | (n > 0) && (f n > f (n-1)) = isCrescent f (n-1)
               | otherwise = False  

fold :: (t -> t -> t) -> [t] -> t
fold f [a] = a 
fold f (a:as) = f a (fold f as)

sumList2 = fold (+) 

subList = fold (-) 

contains :: Int -> [Int] -> Bool 
contains n [] = False  
contains n (x:xs) | n == x = True 
                  | otherwise = contains n xs

intersect :: [Int] -> [Int] -> [Int]
intersect [] _ = []
intersect (x:xs) y | contains x y = x : intersect xs y
                   | otherwise = intersect xs y

--inter xs ys = [a|a <- xs, a `elem` ys]

--uniao x y = x + y

square2 :: [Int] -> [Int]
square2 = map f 
    where f x = x * x

-- square l = map (\ a -> a * a) l

sumSquare3 :: [Int] -> Int
sumSquare3 l = fold (+) (square2 l)


positives :: [Int] -> [Int]
positives = filter f
    where f x = x > 0

-- positives l = filter (\ a -> a > 0)

twice :: (t -> t) -> (t -> t)
twice f = f . f

-- Aplicacoa parcial

multiply :: Int -> Int -> Int 
multiply a b = a*b 

doubleList2 :: [Int] -> [Int]
doubleList2 = map (multiply 2)

i :: [Int] -> [Int]
i = filter (>0) . map (+1) 

addNum n = (+n)

data Estacao = Inverno | Verao | Outono | Primavera
data Temp = Frio | Quente 

clima :: Estacao -> Temp
clima Inverno = Frio
clima _ = Quente

type Name = String 
type Age = Int 
data People = Person Name Age 

p1 = Person "José" 22
p2 = Person "Maria" 23

showPerson :: People -> String 
showPerson (Person n a) = n ++ " -- " ++ show a 

-- Tipos de dados recursivos

data Expr = Lit Int | Add Expr Expr | Sub Expr Expr 

v1 = Lit 1 -- 1
v2 = Add (Lit 1) (Lit 2) -- 1+2
v3 = Sub v2 v1   -- (1+2) - 1

eval :: Expr -> Int 
eval (Lit n) = n 
eval (Add a b) = eval a + eval b 
eval (Sub a b) = eval a - eval b

teste1 = eval v1 == 1
teste2 = eval v2 == 3
teste3 = eval v3 == 2
resultadoTeste = foldl (&&) True  [teste1, teste2, teste3]

showExpr :: Expr -> String 
showExpr (Lit n) = show n
showExpr (Add a b) = "(" ++ showExpr a ++ " + " ++ showExpr b ++ ")"
showExpr (Sub a b) = "(" ++ showExpr a ++ " - " ++ showExpr b ++ ")"

teste1ShowExpr = showExpr v1 == "1"
teste2ShowExpr = showExpr v2 == "(1 + 2)"
teste3ShowExpr = showExpr v3 == "((1 + 2) - 1)"
resultadoTesteShowExpr = foldl (&&) True  [teste1ShowExpr, teste2ShowExpr, teste3]

----------------------------

data Tree t = NilT | Node t (Tree t) (Tree t) deriving (Eq, Ord, Show)

depth :: Tree t -> Int 
depth NilT = 0
depth (Node n left right) = 1 + maxi (depth left) (depth right) 

t1 = Node 1 NilT NilT 
t2 = Node 2 t1 NilT 
t3 = Node 3 (Node 4 t1 t1) t2
t4 = Node "olha o mamaco" NilT (Node "o mamaco" NilT NilT)

infix_ :: Tree t -> [t]
infix_ NilT = []
infix_ (Node n left right) = infix_ left ++ [n] ++ infix_ right

postfix_ :: Tree t -> [t]
postfix_ NilT = []
postfix_ (Node n left right) = postfix_ left ++ postfix_ right ++ [n]

prefix_ :: Tree t -> [t]
prefix_ NilT = []
prefix_ (Node n left right) = [n] ++ prefix_ left ++ prefix_ right

mapTree :: (t -> u) -> Tree t -> Tree u 
mapTree f NilT = NilT
mapTree f (Node n left right) = Node (f n) (mapTree f left) (mapTree f right)

teste1mapTree = mapTree (+1) t1 == Node 2 NilT NilT
teste2mapTree = mapTree (*2) t2 == Node 4 (Node 2 NilT NilT) NilT

data Tree2 = NilT2 | Node2 Int Tree2 Tree2

foldTree f NilT2 = 0
foldTree f (Node2 n left right) = f n (f (foldTree f left) (foldTree f right))

arvore :: Tree2
arvore = Node2 1 (Node2 2 (Node2 4 NilT2 NilT2) (Node2 5 NilT2 NilT2)) (Node2 3 (Node2 6 NilT2 NilT2) NilT2)

arvore2 :: Tree2
arvore2 = Node2 34 (Node2 5 NilT2 NilT2) NilT2

sumTree = foldTree (+)

sumTree2 NilT2 = 0
sumTree2 (Node2 n left right) = n + sumTree2 left + sumTree2 right

type Pessoa = String
type Idade = Int

buscaIdade :: Pessoa -> [(Pessoa, Idade)] -> Maybe Idade
buscaIdade _ [] = Nothing
buscaIdade p ((pessoa,i):xs) 
            | p == pessoa = Just i 
            | otherwise = buscaIdade p xs

pessoas = [("maria", 20), ("ana", 21), ("guilherme", 22)]


myFunc :: String -> [(String, Int)] -> Maybe [(String, Int)]
myFunc s [] = Nothing 
myFunc s ((s2,i):xs)
           | s == s2 = Just ((s2, i - 1) : xs)
           | otherwise = ((s2, i) :) <$> myFunc s xs

--exercicios


isDec :: [Int] -> Bool
isDec [] = True
isDec [x] = True
isDec (x:y:xs) = (x > y) && isDec (y:xs)

isDec2 x = fold (&&) (map(\(x,y) -> x > y) (zip x (tail x)))