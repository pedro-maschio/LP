module Interpreter where

import AbsLE
import Prelude hiding (lookup)

qs [] = []
qs (a:as)  =  qs [e| e <- as, e < a] ++ [a] ++ qs [e| e <- as, e >= a]


eval :: RContext -> Exp -> Integer

eval context x = case x of
    ELet defs exp -> evalCore context (ELet (qs defs) exp) 
    _             -> evalCore context x


evalCore context x = case x of
    ELet [] exp  -> evalCore context exp
    ELet ((Def id expr):ds) exp -> evalCore (update context (getStr id) (evalCore context expr))  (ELet ds exp)
    EAdd exp0 exp  -> evalCore context exp0 + evalCore context exp
    ESub exp0 exp  -> evalCore context exp0 - evalCore context exp
    EMul exp0 exp  -> evalCore context exp0 * evalCore context exp
    EDiv exp0 exp  -> evalCore context exp0 `div` evalCore context exp
    EInt n  -> n
    EVar id  -> lookup context (getStr id)


type RContext = [(String,Integer)]

getStr :: Ident -> String
getStr (Ident s) = s

lookup :: RContext -> String -> Integer
lookup ((i,v):cs) s
   | i == s = v
   | otherwise = lookup cs s

update :: RContext -> String -> Integer -> RContext
update [] s v = [(s,v)]
update ((i,v):cs) s nv
  | i == s = (i,nv):cs
  | otherwise = (i,v) : update cs s nv
